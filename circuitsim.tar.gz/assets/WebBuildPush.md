After normal git push
python -m pygbag --build --disable-sound-format-error .
python .\patch_index.py
git add -f build/web
git commit -m "build"
git subtree push --prefix build/web origin gh-pages